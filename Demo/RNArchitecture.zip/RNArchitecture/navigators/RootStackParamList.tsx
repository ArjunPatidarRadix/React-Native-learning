export type RootStackParamList = {
    Welcome: undefined;
    Login: undefined;
    SignUp: undefined;
};