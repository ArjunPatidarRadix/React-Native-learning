
export const Images = {
    Welcome: require('./welcome.png')
}