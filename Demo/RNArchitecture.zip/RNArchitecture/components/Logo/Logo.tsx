import React from 'react';
import { View, Image, StyleSheet } from 'react-native';
import { Images } from '../../assets/images';
interface Props {
    //  image: string;
}
const Logo: React.FC<Props> = ({ }) => {
    return (
        <View>
            <Image
                style={styles.tinyLogo}
                source={Images.Welcome}
            />
        </View>
    );
};
const styles = StyleSheet.create({

    tinyLogo: {
        height: 150,
        width: '100%',
        alignSelf: 'center'
    },
});
export default Logo;