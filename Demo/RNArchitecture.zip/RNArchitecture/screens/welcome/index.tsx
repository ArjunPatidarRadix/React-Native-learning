import React from 'react';
import { SafeAreaView, View, ViewStyle } from 'react-native';
import AppButton from '../../components/Button/AppButton';
import Logo from '../../components/Logo/Logo';
import styles from './styles';

interface Props {

}

const WelcomeScreen: React.FC<Props> = ({ navigation }) => {
    return (
        <SafeAreaView style={styles.container}>
            {/* <Logo /> */}
            <View style={styles.btnView}>
                <AppButton text={'SIGN IN'} onPress={() => { navigation.navigate('Login') }} containerStyle={styles.signInBtn} />
                <AppButton text={'SIGN UP'} onPress={() => { }} containerStyle={styles.signUpBtn} />
            </View>
        </SafeAreaView>
    );
};

export default WelcomeScreen;