export const Colors = {
    white: '#ffffff',
    primary: '#ef835d',
    secondary: '#2c365a',
    tertiary: '#85c6d8',
    gray: '#d1d5db',
    graylight: '#F3F4F6',
    grayDark: '#4B5563',
    accent: '#fbcd77',
    turquoise: `#AFEEEE`,
    black: "#000000",
    gold: "#FFD700",
    orange: '#FFA500',
    cyan: '#00CED1'
}